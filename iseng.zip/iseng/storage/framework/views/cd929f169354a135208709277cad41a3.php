

<?php $__env->startSection('title', 'Deleted Category'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Main Area Content -->
        <h1>Deleted List Categories</h1>

        <div class="my-4 d-flex justify-content-end">
            <a href="/categories" class="btn btn-primary mb-3">Back</a>
        </div>

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                DataTable Rent Log
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Action</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $deletedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop-> iteration); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td>
                            <a href="/categories/restore/<?php echo e($category->slug); ?>"  class="badge bg-success text-decoration-none text-white">Restore <span data-feather="edit"></span></a>
     
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\iseng\resources\views/categories/deletedList.blade.php ENDPATH**/ ?>