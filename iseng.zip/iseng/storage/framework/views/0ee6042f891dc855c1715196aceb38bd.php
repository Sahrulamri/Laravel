

<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Main Area Content -->
        <h1>List Registered Users</h1>

        <div class="my-4 d-flex justify-content-end">
            
            
            <a href="/users" class="btn btn-primary mb-3">Approved User List</a>
            
            
            
            
        </div>

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                DataTable Users
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Phone</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $registeredUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->username); ?></td>
                            <td>
                              <?php if($item->phone): ?>
                                  <?php echo e($item->phone); ?>

                              <?php else: ?>
                                  -
                              <?php endif; ?>
                            </td>
                            <td>
                                <a href="/users/detail/<?php echo e($item->slug); ?>"  class="badge bg-warning text-decoration-none text-white">Detail <span data-feather="edit"></span></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\iseng\resources\views/users/registered.blade.php ENDPATH**/ ?>