

<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Main Area Content -->
    <h1>Detail User</h1>

        <div class="my-4 d-flex justify-content-end">
            <?php if($user->status == 'inactive'): ?>
            <a href="/users/approve/<?php echo e($user->slug); ?>" class="btn btn-primary mb-3 me-3">Approve User</a>
            <a href="/users" class="btn btn-info mb-3 me-3">Back</a>
            <a href="/users/registered" class="btn btn-warning mb-3">Back To New Regiter User</a>
            <?php else: ?>
            <a href="/users" class="btn btn-info mb-3 me-4">Back</a>
            <a href="/users/registered" class="btn btn-warning mb-3">Back To New Regiter User</a>
            <?php endif; ?>
            
        </div>

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            
            <div class="row">
                <div class="col-xl-5">
                    <div class="d-flex">
                        <i class="bi bi-person-fill fs-2 me-3"></i><h2>User Profile</h2>
                    </div>
                    <div class="card mb-4">
                        <div class="form-group mb-4 mx-3">
                            <label for="username" class="mb-2">Username :</label>
                            <input type="text" class="form-control" id="username" readonly value="<?php echo e($user->username); ?>">
                        </div>
                        <div class="form-group mb-4 mx-3">
                            <label for="phone" class="mb-2">Phone :</label>
                            <input type="text" class="form-control text-left d-flex" id="phone" readonly value="<?php echo e($user->phone); ?>">
                            
                        </div>
                        <div class="form-group mb-4 mx-3">
                            <label for="address" class="mb-2">Address :</label>
                            <input type="text" class="form-control" id="address" readonly value="<?php echo e($user->address); ?>">
                        </div>
                        <div class="form-group mb-4 mx-3">
                            <label for="status" class="mb-2">Status :</label>
                            <input type="text" class="form-control" id="status" readonly value="<?php echo e($user->status); ?>">
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-7">
                    <div class="d-flex">
                        <i class="bi bi-clock-history fs-3 me-3"></i><h2>User Rent Log</h2>
                    </div>
                   <div class="card mb-4">
                       <?php if (isset($component)) { $__componentOriginal1c153b08db3e4caa96ee92ea0464379b = $component; } ?>
<?php $component = App\View\Components\RentLogTable::resolve(['rentlog' => $rent_logs] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rent-log-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\RentLogTable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c153b08db3e4caa96ee92ea0464379b)): ?>
<?php $component = $__componentOriginal1c153b08db3e4caa96ee92ea0464379b; ?>
<?php unset($__componentOriginal1c153b08db3e4caa96ee92ea0464379b); ?>
<?php endif; ?>
                   </div>
                </div>
            
            </div>
      
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\iseng\resources\views/users/detail.blade.php ENDPATH**/ ?>