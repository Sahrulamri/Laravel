<div>
    <!-- If you do not have a consistent goal in life, you can not live it in a consistent way. - Marcus Aurelius -->
    <table class="table table-hover">
        <thead>
            <tr >
                <th>No.</th>
                <th>Users</th>
                <th>Book</th>
                <th>Rent Date</th>
                <th>Return Date</th>
                <th>Actual Return Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rentlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="<?php echo e($item->actual_return_date == null ? '' : ($item->return_date < $item->actual_return_date ? 'text-bg-danger' : 'text-bg-success')); ?>">
                  <td><?php echo e($rentlog->firstItem() + $key); ?></td>
                  <td><?php echo e($item->user->username); ?></td>
                  <td><?php echo e($item->book->title); ?></td>
                  <td><?php echo e($item->rent_date); ?></td>
                  <td><?php echo e($item->return_date); ?></td>
                  <td><?php echo e($item->actual_return_date); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo e($rentlog->links()); ?>

</div><?php /**PATH E:\applications\iseng\resources\views/components/rent-log-table.blade.php ENDPATH**/ ?>