

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Main Area Content -->
        <h1 class="mt-4">Selamat Datang <?php echo e(auth()->user()->username); ?> </h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
        <!-- CRUCIALS PART WILL BE CHANGED LIKELY -->
        <div class="row mb-5 justify-content-center">
            <div class="col-xl-4 col-md-6">
                <div class="card bg-primary text-white mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                    <i class="bi bi-journal-bookmark-fill ml-1 top-0" style="font-size: 3.4em; margin-left:40px"></i>
                            </div>
                            <div class="col-8">
                                <p class="text-center mt-2 fs-2">Books</p>
                                <p class="text-center fs-5">Jumlah : <?php echo e($books); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="/books">View Details</a>
                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card bg-warning text-white mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                    <i class="bi bi-columns-gap ml-1 top-0" style="font-size: 3.4em; margin-left:40px"></i>
                            </div>
                            <div class="col-8">
                                <p class="text-center mt-2  fs-2">Categories</p>
                                <p class="text-center  fs-5">Jumlah : <?php echo e($categories); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="/categories">View Details</a>
                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card bg-success text-white mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                    <i class="bi bi-person-vcard ml-1 top-0" style="font-size: 3.4em; margin-left:40px"></i>
                            </div>
                            <div class="col-8">
                                <p class="text-center mt-2  fs-2">Users</p>
                                <p class="text-center  fs-5">Jumlah : <?php echo e($users); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="/users">View Details</a>
                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END CRUCIAL PART -->
        <div class="row">
            <div class="col-xl-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-chart-area me-1"></i>
                        Area Chart Example
                    </div>
                    <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-chart-bar me-1"></i>
                        Bar Chart Example
                    </div>
                    <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                </div>
            </div>
        </div>
        <h3 class="my-3 text-center">Rent Log</h3>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                DataTable Rent Log
            </div>
            <?php if (isset($component)) { $__componentOriginal1c153b08db3e4caa96ee92ea0464379b = $component; } ?>
<?php $component = App\View\Components\RentLogTable::resolve(['rentlog' => $rent_logs] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rent-log-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\RentLogTable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c153b08db3e4caa96ee92ea0464379b)): ?>
<?php $component = $__componentOriginal1c153b08db3e4caa96ee92ea0464379b; ?>
<?php unset($__componentOriginal1c153b08db3e4caa96ee92ea0464379b); ?>
<?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\iseng\resources\views/dashboard.blade.php ENDPATH**/ ?>