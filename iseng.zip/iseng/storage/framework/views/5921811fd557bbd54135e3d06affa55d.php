

<?php $__env->startSection('title', 'Book Rent'); ?>
<?php $__env->startSection('content'); ?>

 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
  <!-- Main Area Content -->
        <h1 class="mb-5 text-center">Book Rent Form</h1>

        <div class="col-xl-6 offset-md-3 col-md-8 offset-md-2">
            <?php if(session()->has('message')): ?>
            <div class="alert <?php echo e(session('alert-class')); ?> alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        </div>
        

        <form action="/bookRent" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-xl-6 offset-md-3 col-md-8 offset-md-2">
                
                <div class="mb-4">
                    <label for="user" class="form-label">User</label>
                    <select class="form-select inputbox" name="user_id" id="user" aria-label="Floating label select example">
                      <option selected>Open this User List</option>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($item->id); ?>"><?php echo e($item->username); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    
                  </div>
                <div class="mb-4">
                    <label for="book" class="form-label">Book</label>
                    <select class="form-select inputbox" name="book_id" id="book" aria-label="Floating label select example">
                      <option selected>Open this Book List</option>
                      <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    
                  </div>
                  <button class="btn btn-primary w-100" type="submit">Submit</button>
            </div>
        </form>
     
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script>
        $(document).ready(function() {
            $('.inputbox').select2();
        });
       
        </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\iseng\resources\views/bookRent.blade.php ENDPATH**/ ?>