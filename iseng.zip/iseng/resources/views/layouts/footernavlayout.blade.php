<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted fs-6 mb-3 col-lg">
                <div class="text-center">
                    Copyright &copy; Rental Buku 2023
                </div>
            </div>
        </div>
    </div>
</footer>