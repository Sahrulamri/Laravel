@extends('layouts.main')
@section('container')
    <h1>If You Have Any Question Or Other Something As May We Can Help</h1>
    <h3>Please Contact Us Below</h3>
    <p>phone : {{ $phone }}</p>
    <p>Instagram : {{ $ig }}</p>
    <p>Whats App : {{ $wa }}</p>
    <p>Facebook : {{ $fb }}</p>
    <h3>Or You want to join with Our Comunity</h3>
    <p>Discord : {{ $dc }}</p>
@endsection