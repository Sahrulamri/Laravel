@extends('layouts.main')
@section('container')
    <h2>Our Documentation</h2>
    <ul>
        <li>1. {{ $info1 }} </li>
        <li>2. {{ $info2 }}</li>
        <li>3. {{ $info3 }}</li>
        <li>4. {{ $info4 }}</li>
        <li>5. {{ $info5 }}</li>
    </ul>

@endsection
