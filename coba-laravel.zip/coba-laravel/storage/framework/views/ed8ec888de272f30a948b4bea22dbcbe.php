
<?php $__env->startSection('container'); ?>
    <h2>Our Documentation</h2>
    <ul>
        <li>1. <?php echo e($info1); ?> </li>
        <li>2. <?php echo e($info2); ?></li>
        <li>3. <?php echo e($info3); ?></li>
        <li>4. <?php echo e($info4); ?></li>
        <li>5. <?php echo e($info5); ?></li>
    </ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\coba-laravel\resources\views/documentation.blade.php ENDPATH**/ ?>