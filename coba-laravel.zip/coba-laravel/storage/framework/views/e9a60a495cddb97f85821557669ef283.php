
<?php $__env->startSection('container'); ?>
    <h1>If You Have Any Question Or Other Something As May We Can Help</h1>
    <h3>Please Contact Us Below</h3>
    <p>phone : <?php echo e($phone); ?></p>
    <p>Instagram : <?php echo e($ig); ?></p>
    <p>Whats App : <?php echo e($wa); ?></p>
    <p>Facebook : <?php echo e($fb); ?></p>
    <h3>Or You want to join with Our Comunity</h3>
    <p>Discord : <?php echo e($dc); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\coba-laravel\resources\views/contact.blade.php ENDPATH**/ ?>