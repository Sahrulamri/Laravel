
<?php $__env->startSection('container'); ?>
    <h1 class="mb-3 text-center">
        <?php echo e($title); ?>

    </h1>

    <div class="row mb-3 justify-content-center">
      <div class="col-md-6">
        <form action="/blog" method="get">
          <?php if(request('category')): ?>
              <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
          <?php endif; ?>

          <?php if(request('author')): ?>
              <input type="hidden" name="author" value="<?php echo e(request('author')); ?>">
          <?php endif; ?>

          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Silahkan masukkan yang anda cari..." name="search" value="<?php echo e(request('search')); ?>">
            <button class="btn btn-danger" type="submit"  >Search</button>
          </div>
        </form>
      </div>
    </div>

    <?php if($posts->count()): ?>
    <div class="card mb-3 ">
        <?php if($posts[0]->image): ?>
          <img src="<?php echo e(asset('storage/' . $posts[0]->image)); ?>" class="img-fluid" style="max-height: 400px; overflow:hidden">
          <?php else: ?>
          <img src="https://source.unsplash.com/1200x400?<?php echo e($posts[0]->category->name); ?>" class="card-img-top" alt="<?php echo e($posts[0]->category->name); ?>">
          <?php endif; ?>
        
        <div class="card-body text-center">
          <h3 class="card-title"><a href="/post/<?php echo e($posts[0]->slug); ?>" class="text-decoration-none text-dark"><?php echo e($posts[0]->title); ?></a></h3>
          <p class="card-text"><?php echo e($posts[0]->excerpt); ?>.</p>
          <p>By <a href="/blog?author=<?php echo e($posts[0]->author->username); ?>" class="text-decoration-none"><?php echo e($posts[0]->author->name); ?></a> in <a href="/blog?category=<?php echo e($posts[0]->category->slug); ?>" class="text-decoration-none"><?php echo e($posts[0]->category->name); ?></a></p>
          
          <a href="/post/<?php echo e($posts[0]->slug); ?>" class="text-decoration-none btn btn-primary">Read More</a>
          <p class="card-text"><small class="text-muted"><?php echo e($posts[0]->created_at->diffForHumans()); ?></small></p>
        </div>
      </div>
    

      <div class="container">
        <div class="row">
            <?php $__currentLoopData = $posts->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="position-absolute text-white px-4 py-2" style="background-color: rgba(0, 0, 0, 0.6)">
                        <a href="/blog?category=<?php echo e($post->category->slug); ?>" class="text-decoration-none text-white"><?php echo e($post->category->name); ?></a>
                    </div>
                    <?php if($post->image): ?>
                      <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="img-fluid" style="max-height: 400px; overflow:hidden">
                    <?php else: ?>
                    <img src="https://source.unsplash.com/500x400?<?php echo e($post->category->name); ?>" class="card-img-top" alt="<?php echo e($post->category->name); ?>">
                    <?php endif; ?>
                    
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($post->title); ?></h5>
                      <p>By <a href="/blog?author=<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->name); ?></a></p>

                      <?php echo $post->excerpt; ?>

                      <br>

                      <a href="/post/<?php echo e($post->slug); ?>" class="btn btn-primary mt-3">Read More</a>
                    </div>
                  </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <?php else: ?>
      <p class="text-center fs-3">Post Not Found</p>
  <?php endif; ?>

  <div class="d-flex justify-content-center mx-3 my-5">
      <?php echo e($posts->links()); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\coba-laravel\resources\views/posts.blade.php ENDPATH**/ ?>