
<?php $__env->startSection('container'); ?>

    <h1>Title News</h1>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fugiat autem velit quam odio pariatur. Labore possimus ab repellendus unde iste deserunt architecto autem eius? Debitis et, aut doloremque rerum, dicta ab voluptatum quis vero perspiciatis est nisi accusantium quam corrupti sapiente magni laudantium perferendis placeat. Deserunt dolores quis sequi iusto harum necessitatibus vero quas nesciunt mollitia?</p>
    <br>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Obcaecati ipsam nemo ut cumque. Corrupti doloribus quos nulla neque animi iste voluptas sit illo repellat, quia porro autem harum rerum minus blanditiis. Fuga expedita qui veritatis nihil laborum sapiente quo, itaque aspernatur dolorum inventore.</p>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ea, commodi esse quibusdam beatae provident deleniti harum amet culpa id quasi optio minima modi. Nostrum, officia exercitationem perferendis sapiente illum voluptates.</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\coba-laravel\resources\views/news.blade.php ENDPATH**/ ?>