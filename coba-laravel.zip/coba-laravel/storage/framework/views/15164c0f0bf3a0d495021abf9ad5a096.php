
<?php $__env->startSection('container'); ?>

    <h1 class="mb-5">Post Category : <?php echo e($category); ?></h1>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/post/<?php echo e($post->slug); ?>" class="text-decoration-none"><h2><?php echo e($post->title); ?></h2></a>
        <h5>By : <a href="/authors/<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->name); ?></a></h5>
        <?php echo $post->excerpt; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a href="/blog" class="d-block mt-4 text-decoration-none mb-5 ">Back To Post</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\coba-laravel\resources\views/category.blade.php ENDPATH**/ ?>